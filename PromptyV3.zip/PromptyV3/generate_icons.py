#!/usr/bin/env python3
"""
Generate PNG icons for the Prompt Compiler Chrome Extension
This script creates the required icon sizes from the icon.svg
"""

import os
import sys

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("❌ Pillow not installed. Installing...")
    os.system("pip install Pillow")
    from PIL import Image, ImageDraw, ImageFont

def create_extension_icons():
    """Create extension icons in various sizes"""
    
    # Create icons directory if it doesn't exist
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    os.makedirs(icons_dir, exist_ok=True)
    
    # Icon sizes
    sizes = [
        (16, "icon-16.png"),
        (48, "icon-48.png"),
        (128, "icon-128.png"),
    ]
    
    # Colors (gradient purple)
    gradient_colors = {
        16: (102, 126, 234),   # Purple - lighter
        48: (102, 126, 234),
        128: (102, 126, 234),
    }
    
    for size, filename in sizes:
        print(f"Creating {size}x{size} icon...")
        
        # Create image with gradient background
        img = Image.new("RGB", (size, size), color=gradient_colors[size])
        draw = ImageDraw.Draw(img)
        
        # Add darker gradient effect
        darker = tuple(max(0, c - 30) for c in gradient_colors[size])
        for i in range(size):
            ratio = i / size
            blended = tuple(
                int(gradient_colors[size][j] * (1 - ratio) + darker[j] * ratio)
                for j in range(3)
            )
            draw.line([(0, i), (size, i)], fill=blended)
        
        # Add sparkle effect (white dot)
        sparkle_size = max(2, size // 8)
        sparkle_pos = (size // 4, size // 4)
        draw.ellipse(
            [
                (sparkle_pos[0] - sparkle_size, sparkle_pos[1] - sparkle_size),
                (sparkle_pos[0] + sparkle_size, sparkle_pos[1] + sparkle_size)
            ],
            fill="white"
        )
        
        # Add text for smaller icons or star for larger
        if size >= 16:
            # Try to add ✨ emoji/character
            try:
                # Add white rounded rectangle for text area
                rect_margin = max(2, size // 8)
                draw.rectangle(
                    [(rect_margin, rect_margin), (size - rect_margin, size - rect_margin)],
                    fill=(*gradient_colors[size], 128),  # Semi-transparent
                    outline="white"
                )
                
                # Add small sparkle character
                if size >= 48:
                    # Draw sparkle using lines
                    center = (size // 2, size // 2)
                    arm_length = size // 6
                    # Horizontal and vertical lines
                    draw.line(
                        [(center[0] - arm_length, center[1]), (center[0] + arm_length, center[1])],
                        fill="white",
                        width=2
                    )
                    draw.line(
                        [(center[0], center[1] - arm_length), (center[0], center[1] + arm_length)],
                        fill="white",
                        width=2
                    )
            except Exception as e:
                print(f"  ⚠️  Warning: Could not add text to {size}x{size} - {e}")
        
        # Save icon
        filepath = os.path.join(icons_dir, filename)
        img.save(filepath, "PNG")
        print(f"✅ Created: {filepath}")
    
    print("\n✨ All icons created successfully!")
    print(f"📁 Icons saved to: {icons_dir}")
    print("\n Next step: Install extension in Chrome")
    print("  1. Open chrome://extensions/")
    print("  2. Enable Developer mode")
    print("  3. Click 'Load unpacked'")
    print("  4. Select this extension folder")

if __name__ == "__main__":
    try:
        create_extension_icons()
    except Exception as e:
        print(f"❌ Error creating icons: {e}")
        sys.exit(1)
