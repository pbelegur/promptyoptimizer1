# Chrome Web Store Listing — PromptyOptimizer

## Extension Name
PromptyOptimizer - AI Prompt Rewriter

## Short Description (max 132 chars)
Rewrite rough prompts into clear, structured ones. One-click inject into ChatGPT, Claude & Gemini. Free.

## Full Description
---
✨ **Stop getting mediocre answers from AI — it's your prompt, not the AI.**

PromptyOptimizer is a browser extension that acts as a "prompt middleware layer" between you and any AI model. Type a rough, vague, or messy prompt → get a structured, high-quality version → inject it directly into ChatGPT, Claude, or Gemini with one click.

**🚀 How it works:**
1. Click the extension icon
2. Paste your rough prompt (e.g. "explain kafka how it works brokers topics")
3. Hit Optimize — AI rewrites it in ~2 seconds
4. Click "Inject into ChatGPT" — it appears in the chat box automatically

**⚡ Key Features:**

📝 **AI-Powered Rewriting**
Not a simple find-and-replace. Uses LLaMA 3 (via Groq) to understand your intent and reconstruct the prompt with proper structure, specificity, and clarity.

🎯 **3 Optimized Variants**
Get versions tuned for Claude/GPT-4, Gemini, and Mistral — switch between them with one click.

💉 **One-Click Inject**
Works on ChatGPT, Claude.ai, and Gemini. Click inject and the optimized prompt appears in the chat input automatically.

📊 **Clarity Scoring**
See a 0–100 clarity score for every prompt, plus a "What Changed" breakdown showing exactly what was improved.

📈 **Personal Analytics Dashboard**
Track your usage: total prompts optimized, average clarity improvement, token savings, and a breakdown by category (Coding, Writing, Explaining, Analysis, etc.)

🕒 **Prompt History**
Your last 20 optimizations are saved locally. Click any past prompt to reuse it.

🔒 **100% Private**
Your API key and prompts never leave your browser except to go directly to Groq's API. No backend servers, no data collection, no accounts.

💸 **Completely Free**
Uses Groq's free API tier. No credit card. No subscription. Just sign up at console.groq.com and paste your free API key.

**Real Example:**

Before: *"can u explain kafka in detail but simple and how it works internally like topics partitions brokers etc"*

After:
> Explain Apache Kafka's internal architecture in simple terms.
> 
> Cover:
> - Brokers and their role
> - Topics and message organization  
> - Partitions for scalability
> - Producers and Consumers
> - Offsets for tracking position
> 
> Use a real-world analogy. Keep it beginner-friendly with a short example.

**Who is this for?**
- Developers who use AI coding assistants daily
- Writers and content creators using ChatGPT
- Students and researchers
- Anyone who wants consistently better AI responses

---

## Category
Productivity

## Language
English

## Tags / Keywords
prompt engineering, chatgpt, claude, gemini, AI, prompt optimizer, llm, productivity, chrome extension

---

## Store Listing Images You Need to Create

### 1. Icon (already have)
- 128x128 PNG — already in /icons/

### 2. Screenshots (1280x800 or 640x400)
Take these 5 screenshots after installing:

**Screenshot 1 — Main optimizer view**
- Title: "Paste your rough prompt"
- Show the input box with a messy prompt typed in

**Screenshot 2 — Results view**
- Title: "Get a structured, optimized version"
- Show the metrics (clarity score, token delta) + the "What Changed" list

**Screenshot 3 — Inject button**
- Title: "One-click inject into ChatGPT"
- Show ChatGPT open in background with the extension popup showing the Inject button

**Screenshot 4 — Stats dashboard**
- Title: "Track your improvement over time"
- Show the Stats tab with some data filled in

**Screenshot 5 — History tab**
- Title: "Your last 20 optimizations, always accessible"
- Show the History tab with several past items

### 3. Promotional Tile (440x280) — Optional but recommended
- Purple gradient background (same as extension)
- Big text: "Better Prompts. Better Answers."
- Small text: "AI-powered prompt optimizer"
- Show a before/after comparison

---

## Submission Checklist

1. [ ] Go to https://chrome.google.com/webstore/devconsole
2. [ ] Pay one-time $5 developer registration fee
3. [ ] Click "New Item" → upload a ZIP of the extension folder
4. [ ] Fill in: name, description (copy from above), category = Productivity
5. [ ] Upload screenshots (at least 1 required, 5 recommended)
6. [ ] Set: Does not collect user data (true — everything is local)
7. [ ] Set: Single purpose = "Optimizes AI prompts and injects them into chat interfaces"
8. [ ] Submit for review — takes 1-3 business days

## Privacy Policy (required — host this anywhere, even a GitHub Gist)

---
**PromptyOptimizer Privacy Policy**

PromptyOptimizer does not collect, store, or transmit any personal data to any servers operated by the extension developer.

- Your Groq API key is stored locally in your browser using Chrome's storage API
- Your prompt history and analytics are stored locally in your browser
- Prompts are sent directly from your browser to Groq's API (api.groq.com) — the extension developer never sees them
- No analytics, tracking, or telemetry of any kind

For questions: [your email here]
---
