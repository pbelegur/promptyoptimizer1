// ─── TAB SWITCHING ─────────────────────────────────────────────────────────────
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`tab-${tab}`).classList.add("active");
    if (tab === "stats") loadStats();
    if (tab === "history") loadHistory();
  });
});

// ─── OPTIMIZE TAB ──────────────────────────────────────────────────────────────
const promptInput      = document.getElementById("promptInput");
const optimizeBtn      = document.getElementById("optimizeBtn");
const clearBtn         = document.getElementById("clearBtn");
const copyBtn          = document.getElementById("copyBtn");
const injectBtn        = document.getElementById("injectBtn");
const resultsContainer = document.getElementById("resultsContainer");
const loadingContainer = document.getElementById("loadingContainer");
const messageContainer = document.getElementById("messageContainer");
const optimizedPrompt  = document.getElementById("optimizedPrompt");
const variantsContainer= document.getElementById("variantsContainer");

let currentVariants = [];
let pendingOptimization = false;

// Restore last prompt
chrome.storage.local.get(["lastPrompt"], r => {
  if (r.lastPrompt) promptInput.value = r.lastPrompt;
});
promptInput.addEventListener("input", () => {
  chrome.storage.local.set({ lastPrompt: promptInput.value });
});

optimizeBtn.addEventListener("click", () => {
  const p = promptInput.value.trim();
  if (!p) { showMsg("Please enter a prompt first", "error"); return; }
  if (pendingOptimization) { showMsg("Already optimizing, please wait...", "error"); return; }
  doOptimize(p);
});

clearBtn.addEventListener("click", () => {
  promptInput.value = "";
  chrome.storage.local.remove("lastPrompt");
  hideResults();
  promptInput.focus();
});

copyBtn.addEventListener("click", () => {
  navigator.clipboard.writeText(optimizedPrompt.value);
  copyBtn.textContent = "✓ Copied!";
  setTimeout(() => { copyBtn.innerHTML = "📋 Copy"; }, 2000);
});

injectBtn.addEventListener("click", () => {
  const text = optimizedPrompt.value;
  if (!text) return;
  injectBtn.textContent = "Injecting...";
  injectBtn.disabled = true;

  chrome.runtime.sendMessage({ action: "injectPrompt", promptText: text }, (response) => {
    injectBtn.disabled = false;
    if (response?.success) {
      injectBtn.textContent = "✅ Injected!";
      setTimeout(() => { injectBtn.innerHTML = "⚡ Inject into ChatGPT"; }, 2500);
    } else {
      injectBtn.innerHTML = "⚡ Inject into ChatGPT";
      showMsg(response?.error || "Injection failed. Open ChatGPT first.", "error");
    }
  });
});

document.getElementById("closeBtn").addEventListener("click", hideResults);
document.getElementById("settingsLink").addEventListener("click", () => chrome.runtime.openOptionsPage());

function doOptimize(prompt) {
  pendingOptimization = true;
  showLoading(true);
  hideResults();

  chrome.runtime.sendMessage({ action: "optimizePrompt", prompt }, (response) => {
    pendingOptimization = false;
    showLoading(false);

    if (!response) { showMsg("No response from background script", "error"); return; }
    if (response.error) { showMsg(response.error, "error"); return; }
    if (response.success) { displayResults(response); showResults(); }
  });
}

function displayResults(data) {
  // Metrics
  document.getElementById("clarityScore").textContent = data.clarity_score ? `${data.clarity_score}/100` : "—";

  const ts = document.getElementById("tokenSavings");
  if (data.token_savings !== undefined) {
    ts.textContent = data.token_savings < 0
      ? `+${Math.abs(data.token_savings)}`
      : `${data.token_savings}`;
    ts.style.color = data.token_savings < 0 ? "#f59e0b" : "#667eea";
  }
  document.getElementById("recommendedLLM").textContent = data.recommended_llm || "—";

  // Improvements
  const list = document.getElementById("improvementsList");
  if (data.improvements?.length) {
    list.innerHTML = data.improvements.map(i => `<li>${i}</li>`).join("");
    document.getElementById("improvementsCard").style.display = "block";
  } else {
    document.getElementById("improvementsCard").style.display = "none";
  }

  // Variants
  if (data.optimized?.variants?.length) {
    currentVariants = data.optimized.variants;
    variantsContainer.innerHTML = "";
    currentVariants.forEach((v, i) => {
      const btn = document.createElement("button");
      btn.className = "variant-btn" + (i === 0 ? " active" : "");
      btn.textContent = v.llm_name;
      btn.onclick = () => selectVariant(i);
      variantsContainer.appendChild(btn);
    });
    selectVariant(0);
  } else if (data.optimized_prompt) {
    optimizedPrompt.value = data.optimized_prompt;
  }
}

function selectVariant(i) {
  if (i < 0 || i >= currentVariants.length) return;
  optimizedPrompt.value = currentVariants[i].prompt_text || "";
  variantsContainer.querySelectorAll(".variant-btn").forEach((b, idx) => {
    b.classList.toggle("active", idx === i);
  });
}

function showLoading(show) {
  loadingContainer.style.display = show ? "block" : "none";
}
function showResults() {
  resultsContainer.style.display = "block";
}
function hideResults() {
  resultsContainer.style.display = "none";
}
function showMsg(message, type) {
  messageContainer.innerHTML = `<div class="msg ${type}">${message}</div>`;
  setTimeout(() => { messageContainer.innerHTML = ""; }, 5000);
}

// ─── STATS TAB ─────────────────────────────────────────────────────────────────
function loadStats() {
  chrome.runtime.sendMessage({ action: "getAnalytics" }, ({ analytics: a }) => {
    document.getElementById("statTotal").textContent = a.total;
    document.getElementById("statAvgClarity").textContent =
      a.total > 0 ? Math.round(a.claritySum / a.total) : 0;
    document.getElementById("statTokens").textContent = a.tokensSaved;

    // Top category
    const cats = a.categories;
    const topCat = Object.keys(cats).sort((x, y) => cats[y] - cats[x])[0];
    document.getElementById("statTopCat").textContent = topCat || "—";

    // Category bars
    const total = Object.values(cats).reduce((s, v) => s + v, 0) || 1;
    const colors = ["#667eea","#764ba2","#10b981","#f59e0b","#ef4444","#6b7280"];
    const container = document.getElementById("categoryBars");
    container.innerHTML = Object.keys(cats).length === 0
      ? `<div style="color:#aaa; font-size:12px; text-align:center; padding:12px 0;">No data yet — optimize some prompts!</div>`
      : Object.entries(cats)
          .sort((a, b) => b[1] - a[1])
          .map(([cat, count], i) => `
            <div class="cat-bar">
              <div class="cat-label">
                <span>${cat}</span>
                <span>${count} prompt${count !== 1 ? "s" : ""}</span>
              </div>
              <div class="bar-track">
                <div class="bar-fill" style="width:${Math.round(count/total*100)}%; background:${colors[i % colors.length]};"></div>
              </div>
            </div>`).join("");
  });
}

// ─── HISTORY TAB ───────────────────────────────────────────────────────────────
function loadHistory() {
  chrome.runtime.sendMessage({ action: "getAnalytics" }, ({ history }) => {
    const container = document.getElementById("historyList");
    if (!history.length) {
      container.innerHTML = `<div class="history-empty">No history yet.<br>Start optimizing prompts!</div>`;
      return;
    }
    container.innerHTML = history.map(item => `
      <div class="history-item" onclick="reusePrompt(${JSON.stringify(item.original).replace(/"/g, '&quot;')})">
        <div class="history-meta">
          <span class="history-cat">${item.category}</span>
          <span>${item.date} · ${item.clarity}/100</span>
        </div>
        <div class="history-orig">Before: ${escHtml(item.original)}</div>
        <div class="history-opt">After: ${escHtml(item.optimized)}</div>
      </div>`).join("");
  });
}

function reusePrompt(original) {
  // Switch to optimizer tab and paste
  document.querySelector('[data-tab="optimizer"]').click();
  document.getElementById("promptInput").value = original;
  chrome.storage.local.set({ lastPrompt: original });
}

function escHtml(t) {
  return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
