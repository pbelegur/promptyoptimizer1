const apiKeyInput = document.getElementById("apiKey");
const saveBtn = document.getElementById("saveBtn");
const statusMsg = document.getElementById("statusMsg");
const toggleBtn = document.getElementById("toggleVisibility");
const statusDot = document.getElementById("statusDot");
const keyStatus = document.getElementById("keyStatus");

chrome.storage.local.get(["groqApiKey"], (result) => {
  if (result.groqApiKey) {
    apiKeyInput.value = result.groqApiKey;
    setKeyStatus(true);
  }
});

toggleBtn.addEventListener("click", () => {
  const isPassword = apiKeyInput.type === "password";
  apiKeyInput.type = isPassword ? "text" : "password";
  toggleBtn.textContent = isPassword ? "🙈 Hide key" : "👁 Show key";
});

saveBtn.addEventListener("click", () => {
  const key = apiKeyInput.value.trim();
  if (!key) { showStatus("Please enter an API key", "error"); return; }
  if (!key.startsWith("gsk_")) {
    showStatus("That doesn't look like a Groq API key (should start with gsk_)", "error");
    return;
  }
  chrome.storage.local.set({ groqApiKey: key }, () => {
    setKeyStatus(true);
    showStatus("✓ API key saved! You can now use PromptyOptimizer.", "success");
  });
});

function setKeyStatus(saved) {
  statusDot.className = "dot" + (saved ? " green" : "");
  keyStatus.textContent = saved ? "Key saved ✓" : "No key saved";
}

function showStatus(msg, type) {
  statusMsg.textContent = msg;
  statusMsg.className = `status ${type}`;
  statusMsg.style.display = "block";
  setTimeout(() => { statusMsg.style.display = "none"; }, 4000);
}
