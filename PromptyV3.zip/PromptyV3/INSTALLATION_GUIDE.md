# 🎯 Quick Start Guide - Prompt Compiler Extension

## Step 1: Ensure Backend is Running ✅

Make sure your API is running:

```bash
cd c:\Users\Devi\Downloads\PromptEngineering
venv\Scripts\python -m uvicorn app.main:app --reload
```

You should see:
```
✓ All systems operational!
INFO:     Application startup complete.
```

Visit http://localhost:8000 to verify it's working.

---

## Step 2: Create Icons (Quick Alternative)

Since the extension needs PNG icons, here are two approaches:

### Option A: Use SVG Directly (Easiest)
The `icon.svg` file can be referenced directly in some browsers:

1. Open `extension/manifest.json`
2. Change this line:
   ```json
   "default_icons": {
     "16": "icon.svg",
     "48": "icon.svg",
     "128": "icon.svg"
   }
   ```

### Option B: Create Simple PNG Icons (Recommended)

Create three simple PNG files and place in `extension/icons/` folder:

**16x16.png:**
- Simple purple square with white emoji ✨

**48x48.png:**
- Same design, larger

**128x128.png:**
- Same design, largest

**Quick way to create:**
1. Open Paint (Windows)
2. Create 16x16 image
3. Draw purple square
4. Add white character
5. Save as `16-16.png`
6. Repeat for 48x48 and 128x128

---

## Step 3: Install Extension in Chrome 🚀

### On Windows:

1. **Open Chrome Extensions Page**
   ```
   Type in address bar: chrome://extensions/
   ```

2. **Enable Developer Mode**
   - Toggle switch in top-right corner (ON)

3. **Load Unpacked Extension**
   - Click "Load unpacked"
   - Navigate to: `c:\Users\Devi\Downloads\PromptEngineering\extension\`
   - Click "Select Folder"

4. **Verify Installation**
   - Extension appears in your extensions list
   - Icon appears in top-right toolbar
   - Shows version 1.0.0

### If you see errors:
- Check that icons folder exists and has PNG files
- Or use SVG approach above
- Click refresh icon next to extension name

---

## Step 4: Test the Extension 🧪

### Method 1: In ChatGPT (Best)

1. Go to https://chat.openai.com
2. Type a simple prompt:
   ```
   give me a picture of a old man smoking
   ```
3. You should see **✨ Optimize** button appear below the text area
4. Click the button
5. A popup should appear with:
   - Original vs Optimized prompt
   - Clarity score
   - Token savings
   - Quality improvements

### Method 2: Using Popup

1. Click extension icon in toolbar
2. Paste a prompt
3. Click "Optimize"
4. See results

---

## Step 5: Fix Common Issues 🔧

### "Extension not loading"
```
❌ Error: Failed to load manifest
✅ Solution: 
   - Verify manifest.json syntax (no trailing commas)
   - Ensure all JS files exist
   - Check icons folder path
```

### "No ✨ Optimize button in ChatGPT"
```
❌ Problem: Button doesn't appear
✅ Solution:
   1. Hard refresh ChatGPT: Ctrl+Shift+R
   2. Check console: F12 → Console tab
   3. Should see: "Prompt Compiler Extension ready"
   4. If not, extension didn't load
   5. Reload extension in chrome://extensions/
```

### "Connection refused error"
```
❌ Error: API at localhost:8000 not reachable
✅ Solution:
   1. Make sure backend is running (Step 1)
   2. Test API: http://localhost:8000
   3. API should return JSON response
   4. Check API endpoint in background.js
```

### "Optimization takes forever"
```
❌ Problem: Response hangs for 20+ seconds
✅ Solution:
   - First request loads AI models (~20-30s)
   - Subsequent requests < 1 second
   - This is normal on first use
```

---

## Step 6: Start Using! 🎉

### In ChatGPT:
1. Write your prompt
2. Click **✨ Optimize**
3. Review the optimized version
4. Click **Use Optimized Prompt** to replace
5. Hit Send!

### Expected Results:
- **Original:** `give me a picture of a old man smoking`
- **Optimized:** `dramatic portrait of a weathered elderly man smoking a cigar, warm vintage tones, oil painting style, detailed facial features, high quality, museum-quality artwork`
- **Savings:** 9 tokens → more detailed
- **Quality:** 60/100 → 90/100 improvement

---

## Troubleshooting Commands

### Check if API is running:
```powershell
curl http://localhost:8000
# Should return: {"message":"Prompt Compiler API Running",...}
```

### Test optimization endpoint:
```powershell
$json = @{text="test prompt"} | ConvertTo-Json
curl -X POST http://localhost:8000/api/compiler/compile `
  -ContentType "application/json" `
  -Body $json
# Should return optimization results
```

### Reload extension:
```
chrome://extensions/ → Find Prompt Compiler → Click refresh icon
```

---

## File Structure

```
extension/
├── manifest.json          ← Main config file
├── background.js          ← API communication
├── content.js             ← ChatGPT page injection
├── popup.html             ← Popup UI
├── popup.js               ← Popup logic
├── styles.css             ← ChatGPT button styles
├── icons/                 ← PNG icons folder
│   ├── icon-16.png
│   ├── icon-48.png
│   └── icon-128.png
├── icon.svg               ← SVG version (optional)
├── README.md              ← Full documentation
└── INSTALLATION_GUIDE.md  ← This file
```

---

## Next Steps 🚀

After getting it working:

1. **Test with different prompts**
   - Image generation
   - Code writing
   - Analysis tasks

2. **Check token savings**
   - See how many tokens you save
   - Track cost reductions

3. **Customize settings** (Coming soon)
   - Change animation speed
   - Toggle auto-optimize
   - Custom optimization rules

4. **Extend to other platforms**
   - Add Claude.ai support
   - Add Gemini support
   - Add other AI platforms

---

## Still Having Issues?

1. Open browser console: **F12**
2. Go to **Console** tab
3. Look for error messages
4. Compare with this guide

Common console errors:
```
❌ "Prompt Compiler Extension loaded" missing?
   → Extension didn't inject into page
   → Check content.js for textarea selector

❌ "Cannot read property 'value' of null"
   → Page structure changed
   → ChatGPT might have updated HTML
   → Update textarea selector in content.js

❌ "Manifest parsing error"
   → JSON syntax error in manifest.json
   → Check for trailing commas or quotes
```

---

## Success! ✅

When it's working, you'll see:
1. **Extension icon** in toolbar ✓
2. **✨ Optimize button** appears on ChatGPT ✓
3. **Popup opens** when clicked ✓
4. **Results show** with quality scores ✓
5. **Optimized prompt** appears ✓

Congratulations! 🎉 Your Prompt Compiler extension is live!

---

**Questions?** Check the main [README.md](README.md) for full documentation.
