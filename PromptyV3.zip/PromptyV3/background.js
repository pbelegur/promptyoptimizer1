console.log("PromptyOptimizer background worker initialized");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "optimizePrompt") {
    optimizeWithGroq(request.prompt)
      .then(async result => {
        if (result.success) await trackAnalytics(request.prompt, result);
        sendResponse(result);
      })
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }

  if (request.action === "injectPrompt") {
    injectIntoActiveTab(request.promptText)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === "getAnalytics") {
    getAnalytics().then(data => sendResponse(data));
    return true;
  }

  if (request.action === "ping") {
    sendResponse({ status: "ok" });
  }
});

// ─── ANALYTICS ────────────────────────────────────────────────────────────────

async function trackAnalytics(originalPrompt, result) {
  const data = await chrome.storage.local.get(["analytics"]);
  const a = data.analytics || {
    total: 0,
    claritySum: 0,
    tokensSaved: 0,
    categories: {}
  };

  a.total += 1;
  a.claritySum += result.clarity_score || 0;
  a.tokensSaved += Math.max(0, result.token_savings || 0);

  const cat = detectCategory(originalPrompt);
  a.categories[cat] = (a.categories[cat] || 0) + 1;

  // Store last 20 history items
  const historyData = await chrome.storage.local.get(["history"]);
  const history = historyData.history || [];
  history.unshift({
    original: originalPrompt.slice(0, 120),
    optimized: result.optimized_prompt?.slice(0, 120) || "",
    clarity: result.clarity_score,
    category: cat,
    date: new Date().toLocaleDateString()
  });
  if (history.length > 20) history.pop();

  await chrome.storage.local.set({ analytics: a, history });
}

async function getAnalytics() {
  const data = await chrome.storage.local.get(["analytics", "history"]);
  return {
    analytics: data.analytics || { total: 0, claritySum: 0, tokensSaved: 0, categories: {} },
    history: data.history || []
  };
}

function detectCategory(prompt) {
  const p = prompt.toLowerCase();
  if (/code|function|bug|error|python|javascript|sql|api|debug|class|loop/.test(p)) return "Coding";
  if (/write|essay|blog|email|letter|content|article|draft/.test(p)) return "Writing";
  if (/explain|what is|how does|describe|define|understand/.test(p)) return "Explaining";
  if (/analyze|review|compare|evaluate|assess|pros|cons/.test(p)) return "Analysis";
  if (/create|design|build|make|generate|idea/.test(p)) return "Creating";
  return "Other";
}

// ─── INJECT INTO CHATGPT ──────────────────────────────────────────────────────

async function injectIntoActiveTab(promptText) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab) throw new Error("No active tab found.");

  const isSupportedSite =
    tab.url?.includes("chat.openai.com") ||
    tab.url?.includes("chatgpt.com") ||
    tab.url?.includes("claude.ai") ||
    tab.url?.includes("gemini.google.com");

  if (!isSupportedSite) {
    return {
      success: false,
      error: "Open ChatGPT, Claude.ai, or Gemini first, then click Inject."
    };
  }

  // Inject content script if not already there
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (e) {
    // Already injected, that's fine
  }

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tab.id, { action: "injectText", text: promptText }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, error: "Could not reach page. Try refreshing the tab." });
      } else {
        resolve(response || { success: true });
      }
    });
  });
}

// ─── GROQ OPTIMIZATION ────────────────────────────────────────────────────────

async function optimizeWithGroq(userPrompt) {
  const { groqApiKey } = await chrome.storage.local.get(["groqApiKey"]);

  if (!groqApiKey) {
    return {
      success: false,
      error: "No API key set. Click ⚙️ Settings to add your free Groq API key."
    };
  }

  const systemPrompt = `You are an expert prompt engineer. Rewrite the user's rough prompt into a clear, well-structured prompt that gets better AI responses.

IMPORTANT: You must actually rewrite the prompt content. Do not use placeholder text.

Steps:
1. Understand what the user actually wants
2. Rewrite it with clear structure, specificity, and proper formatting
3. Create 3 variants: one for Claude/GPT-4 (detailed), one for Gemini (conversational), one for Mistral (concise)

Return ONLY a JSON object. No markdown. No backticks. No explanation outside the JSON.

JSON structure:
{
  "optimized_prompt": "<your full rewritten prompt here>",
  "clarity_score": <number 0-100>,
  "original_tokens": <estimated token count of input>,
  "optimized_tokens": <estimated token count of your rewrite>,
  "recommended_llm": "Claude / GPT-4",
  "improvements": ["<specific change you made>", "<another change>", "<another change>"],
  "variants": [
    { "llm_name": "Claude / GPT-4", "prompt_text": "<detailed well-structured rewrite>" },
    { "llm_name": "Gemini", "prompt_text": "<conversational rewrite for Gemini>" },
    { "llm_name": "Mistral", "prompt_text": "<shorter concise rewrite for Mistral>" }
  ]
}`;

  const fewShotExample = `User prompt to optimize: "can u explain kafka in simple way like how it works internally brokers topics all that"

Expected output:
{
  "optimized_prompt": "Explain Apache Kafka's internal architecture in simple terms.\\n\\nCover the following concepts:\\n- Brokers: what they are and their role\\n- Topics: how messages are organized\\n- Partitions: how data is split for scalability\\n- Producers and Consumers: how data flows in and out\\n- Offsets: how Kafka tracks message position\\n\\nUse a simple analogy if possible. Keep the explanation beginner-friendly with a short example.",
  "clarity_score": 88,
  "original_tokens": 22,
  "optimized_tokens": 67,
  "recommended_llm": "Claude / GPT-4",
  "improvements": ["Added structured topic list", "Specified beginner-friendly tone", "Requested analogy for clarity", "Removed filler words"],
  "variants": [
    { "llm_name": "Claude / GPT-4", "prompt_text": "Explain Apache Kafka's internal architecture in simple terms.\\n\\nCover the following concepts:\\n- Brokers: what they are and their role\\n- Topics: how messages are organized\\n- Partitions: how data is split for scalability\\n- Producers and Consumers: how data flows in and out\\n- Offsets: how Kafka tracks message position\\n\\nUse a simple analogy if possible. Keep the explanation beginner-friendly with a short example." },
    { "llm_name": "Gemini", "prompt_text": "Can you explain how Apache Kafka works internally? I want to understand brokers, topics, partitions, producers, consumers, and offsets in a simple way with a real-world analogy." },
    { "llm_name": "Mistral", "prompt_text": "Explain Kafka architecture: brokers, topics, partitions, producers, consumers, offsets. Simple explanation with a brief example." }
  ]
}

Now optimize the actual user prompt below. Replace ALL content with real rewrites of THAT prompt. Do not copy the example above.`;

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${groqApiKey}`
    },
    body: JSON.stringify({
      model: "llama-3.1-8b-instant",
      max_tokens: 1500,
      temperature: 0.2,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: fewShotExample + "\n\nUser prompt to optimize: \"" + userPrompt + "\"" }
      ]
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err?.error?.message || `API error ${response.status}`);
  }

  const data = await response.json();
  const rawText = data.choices?.[0]?.message?.content || "";

  let parsed;
  try {
    const clean = rawText.replace(/```json|```/g, "").trim();
    parsed = JSON.parse(clean);
  } catch {
    const match = rawText.match(/\{[\s\S]*\}/);
    if (match) {
      try { parsed = JSON.parse(match[0]); }
      catch { throw new Error("Could not parse response. Try again."); }
    } else {
      throw new Error("Model returned unexpected format. Try again.");
    }
  }

  const isPlaceholder = (t) => !t || t === "optimized version" || t.length < 20;
  if (isPlaceholder(parsed.optimized_prompt)) {
    throw new Error("Model returned placeholder text. Try again.");
  }

  const tokenSavings = (parsed.original_tokens || 0) - (parsed.optimized_tokens || 0);

  return {
    success: true,
    optimized_prompt: parsed.optimized_prompt,
    clarity_score: parsed.clarity_score || 0,
    token_savings: tokenSavings,
    recommended_llm: parsed.recommended_llm || "Claude / GPT-4",
    improvements: parsed.improvements || [],
    optimized: {
      variants: (parsed.variants || []).filter(v => !isPlaceholder(v.prompt_text))
    }
  };
}
