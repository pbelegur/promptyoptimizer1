# 🚀 Prompt Compiler - ChatGPT Browser Extension

Automatically optimize your ChatGPT prompts to save tokens and improve quality!

## ✨ Features

- 📊 **Clarity Scoring** - Get clarity scores for your prompts (0-100)
- 💾 **Token Savings** - See how many tokens you'll save
- 🎯 **auto-detection** - Automatically detects your prompt intent
- 📈 **Quality Metrics** - Completeness, efficiency, and overall quality scores
- 🔄 **Multi-LLM Optimization** - Optimized variants for different AI models
- ⚡ **Real-time** - Instant optimization without page reload
- 📋 **One-click Copy** - Copy optimized prompts with one click

## 📥 Installation

### Prerequisites
- Backend Prompt Compiler API running at `http://localhost:8000`
  ```bash
  # In the main project directory
  venv\Scripts\python -m uvicorn app.main:app --reload
  ```

### Chrome Installation

1. **Navigate to Extension Page**
   - Type `chrome://extensions/` in address bar
   - Enable "Developer mode" (top right toggle)

2. **Load Extension**
   - Click "Load unpacked"
   - Select the `extension` folder from this project
   - Confirm and the extension will appear

3. **Verify Installation**
   - You should see the extension icon in top right
   - Click it to see the popup interface

### Firefox Installation

1. **Navigate to Add-ons Page**
   - Type `about:debugging` in address bar
   - Click "This Firefox" on left

2. **Load Temporary Add-on**
   - Click "Load Temporary Add-on"
   - Select `extension/manifest.json` from this project

3. **Verify Installation**
   - Extension icon appears in toolbar
   - Click to see popup interface

## 🎯 Usage

### Method 1: Using ChatGPT (Recommended)

1. Go to https://chat.openai.com
2. Start typing your prompt in the message box
3. Click the **✨ Optimize** button (appears next to send button)
4. Review the optimization results:
   - See original vs optimized side-by-side
   - Check token savings
   - View quality improvement
5. Choose "Use Optimized Prompt" or "Copy to Clipboard"

### Method 2: Using Extension Popup

1. Click the extension icon in your browser toolbar
2. Paste your prompt in the text area
3. Click **Optimize** button
4. View results:
   - Clarity score (0-100)
   - Token savings
   - Recommended LLM
   - Full optimized prompt
5. Click **Copy** to copy to clipboard

## 🔧 Configuration

### API Endpoint

Edit `background.js` to change API endpoint:
```javascript
const API_BASE = "http://localhost:8000"; // Change this URL
```

### Auto-Update Check

To enable auto-updates, edit `manifest.json`:
```json
"update_url": "https://your-server/updates.xml"
```

## 🎨 Customization

### Change Colors

Edit `popup.html` gradients:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Modify Button Text

Edit `content.js` button label:
```javascript
optimizeBtn.innerHTML = "✨ Optimize"; // Change text here
```

### Adjust Modal Size

Edit `content.js` modal styles:
```javascript
max-width: 800px; // Adjust popup width
max-height: 80vh; // Adjust popup height
```

## 🐛 Troubleshooting

### Extension not showing in ChatGPT

1. Hard reload: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)
2. Check that `content.js` matches ChatGPT selectors
3. Verify extension is enabled in `chrome://extensions/`

### "Connection refused" error

1. Ensure backend API is running:
   ```bash
   venv\Scripts\python -m uvicorn app.main:app --reload
   ```
2. Check API is accessible: http://localhost:8000
3. Verify API endpoint in `background.js`

### Button not appearing

1. Check that extension is enabled
2. Hard refresh ChatGPT page
3. Check browser console (`F12`) for errors
4. Verify textarea selector: `.querySelector("textarea")`

### Optimization takes too long

1. Backend models loading for first time (~20-30s)
2. Subsequent requests faster (< 1 second)
3. Check your internet connection

## 📊 What Gets Optimized

### Detects:
- Vague adjectives (good, nice, cool)
- Ambiguous pronouns (it, that, this)
- Missing context or details
- Contradictory instructions
- Inefficient token usage

### Improves:
- Clarity through explicit language
- Completeness by adding details
- Efficiency by removing redundancy
- LLM compatibility
- Intent clarity

### Generates:
- Optimized prompts for each LLM
- Token savings estimates
- Quality improvement scores
- Specific improvement suggestions

## 🔐 Privacy

- ✅ Prompts sent only to your local API
- ✅ No data stored on external servers
- ✅ No tracking or analytics
- ✅ No third-party integrations
- ✅ Fully offline capable

## 🚀 Advanced Features

### Batch Optimization

Coming soon: Optimize multiple prompts at once

### Custom Rules

Coming soon: Create custom optimization rules

### Export Results

Coming soon: Export optimization history as CSV

### Analytics Dashboard

Coming soon: Track token savings over time

## 📞 Support

For issues or questions:

1. Check browser console (`F12`) for errors
2. Review troubleshooting section
3. Verify API is running at http://localhost:8000
4. Check that you're on ChatGPT (chat.openai.com)

## 🔄 Updates

To update the extension:

1. Download latest version
2. Go to `chrome://extensions/`
3. Find "Prompt Compiler"
4. Click refresh icon
5. Done!

## 📝 Version History

### v1.0.0
- ✅ ChatGPT integration
- ✅ Popup interface
- ✅ Real-time optimization
- ✅ Quality metrics
- ✅ Token savings calculation

## 📄 License

MIT License - Use freely for personal and commercial projects

## 🙏 Credits

Built with:
- FastAPI (Backend)
- Chrome Extension API
- spaCy (NLP)
- Sentence Transformers (Embeddings)
- Tiktoken (Token counting)

---

**Made with ❤️ for ChatGPT power users**
