// PromptyOptimizer content script
// Handles injecting optimized prompts into AI chat interfaces

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "injectText") {
    const result = injectText(request.text);
    sendResponse(result);
  }
  return true;
});

function injectText(text) {
  // ChatGPT uses a contenteditable div with id="prompt-textarea"
  // Claude.ai uses a contenteditable div
  // Gemini uses a rich text area

  const selectors = [
    "#prompt-textarea",                          // ChatGPT (main)
    "div[contenteditable='true'][data-id]",      // ChatGPT (alt)
    ".ProseMirror",                              // Claude.ai
    "rich-textarea div[contenteditable='true']", // Gemini
    "div[contenteditable='true']",               // Generic fallback
    "textarea"                                   // Old-style fallback
  ];

  let target = null;
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) {
      const rect = el.getBoundingClientRect();
      // Must be visible and in lower half of screen (input area)
      if (rect.height > 20 && rect.top > 100) {
        target = el;
        break;
      }
    }
  }

  if (!target) {
    return { success: false, error: "Could not find the chat input box. Make sure you're on the chat page." };
  }

  try {
    target.focus();

    if (target.tagName.toLowerCase() === "textarea") {
      // Standard textarea
      target.value = text;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      // ContentEditable (ChatGPT, Claude, Gemini)
      // Clear existing content
      target.innerHTML = "";

      // Use execCommand for compatibility with React's synthetic events
      target.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);

      // Fire all events React/Vue listen for
      ["input", "change", "keyup", "keydown"].forEach(eventType => {
        target.dispatchEvent(new Event(eventType, { bubbles: true }));
      });
    }

    // Show a brief success toast
    showToast("✅ Prompt injected!");
    return { success: true };

  } catch (err) {
    return { success: false, error: err.message };
  }
}

function showToast(message) {
  // Remove existing toast
  document.getElementById("prompty-toast")?.remove();

  const toast = document.createElement("div");
  toast.id = "prompty-toast";
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    bottom: 80px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 12px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 600;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    z-index: 999999;
    box-shadow: 0 4px 20px rgba(102,126,234,0.5);
    animation: prompty-fadein 0.3s ease;
  `;

  const style = document.createElement("style");
  style.textContent = `
    @keyframes prompty-fadein {
      from { opacity: 0; transform: translateX(-50%) translateY(10px); }
      to   { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2500);
}
